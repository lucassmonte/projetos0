// Importar os módulos necessários utilizados pelo SEQUELIZE
const { DataTypes } = require("sequelize");
const connection = require("./database");

// Definição do modelo (MODEL) que corresponde a uma tabela do banco de dados.
const instrutor = connection.define(
  "instrutor",
  {
    id_instrutor: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    nome_instrutor: {
      type: DataTypes.STRING(50),
      allowNull: true,
    },
    data_nasc: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    endereco: {
      type: DataTypes.STRING(50),
      allowNull: true,
    },
    genero: {
      type: DataTypes.STRING(50),
      allowNull: true,
    },
    email: {
      type: DataTypes.STRING(50),
      allowNull: true,
    },
    telefone: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
  },
  {
    timestamps: true, // Habilita a criação automática de campos de timestamp
    tableName: "instrutor", // Nome da tabela no banco de dados
  }
);

async function sincronizarinstrutor() {
  try {
    await instrutor.sync({ force: false });
    console.log("Tabela 'instrutor' sincronizada com sucesso!");
  } catch (error) {
    console.error("Erro ao sincronizar a tabela 'instrutor': ", error);
  } finally {
    // Fechar a conexão somente após a sincronização ser concluída
    await connection.close();
    console.log("Conexão fechada.");
  }
}

module.exports = {
  instrutor: instrutor,
  sincronizarinstrutor: sincronizarinstrutor
};
