const express = require("express");
const app = express();
app.set("view engine", "ejs");
port = 4000;

const connection = require("./database/database");

connection
.authenticate()
.then(() => {
    console.log("Conexão feita com sucesso!");
})
.catch((msgErro) => {
    console.log(msgErro);
});
const Disciplina = require("./Database/disciplina");
disciplina1= Disciplina.sincronizarDisciplina();

const instrutor = require("./Database/instrutor");
instrutor1= instrutor.sincronizarinstrutor();

app.listen(port, () =>{
    console.log(`A aplicação está rodando na porta ${port}.`);
});
